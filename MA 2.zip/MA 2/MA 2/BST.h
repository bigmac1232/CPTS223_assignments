#ifndef __BST_H
#define __BST_H

#include <iostream>
#include <limits>
#include <vector>
#include <queue>
using namespace std;


/* ----------------------------------------------------------------------------
---- Below is declaration of BST class, referring to textbook, Figure 4.16 ----
---------------------------------------------------------------------------- */

template <typename Comparable>
class BST
{
public:
	BST();
	~BST();
	void makeEmpty();

	const Comparable & findMin() const;
	const Comparable & findMax() const;

	bool contains(const Comparable & x) const;
	void insert(const Comparable & x);
	void remove(const Comparable & x);
	int treeSize() const;
	int treeHeight() const;
	void printInOrder() const;
	void printLevels() const;
	void printMaxPath() const;

private:
	struct BinaryNode
	{
		Comparable element;
		BinaryNode *left;
		BinaryNode *right;

		BinaryNode( const Comparable & theElement, BinaryNode *lt, BinaryNode *rt): element(theElement), left(lt), right(rt) {}
		BinaryNode( Comparable && theElement, BinaryNode *lt, BinaryNode *rt): element(move(theElement)), left(lt), right(rt) {}
	};

	BinaryNode *root;

	BinaryNode * findMin( BinaryNode * t ) const;
	BinaryNode * findMax( BinaryNode * t ) const;
	void makeEmpty( BinaryNode * & t );
};


/* --------------------------------------------------------------
---- Below is implementation of public and private functions ----
-------------------------------------------------------------- */

// constructor
template<typename Comparable>
BST<Comparable>::BST() : root(NULL) {}

// destructor, refer to textbook, Figure 4.27
template<typename Comparable>
BST<Comparable>::~BST() 
{
	makeEmpty();
}

// public makeEmpty: refer to textbook, Figure 4.27
template <typename Comparable>
void BST<Comparable>::makeEmpty() 
{
    makeEmpty(root);
}

// private recursive makeEmpty: refer to textbook, Figure 4.27
template <typename Comparable>
void BST<Comparable>::makeEmpty(BinaryNode *& t) 
{
    if ( t != NULL ) {
        makeEmpty(t->left);
        makeEmpty(t->right);
        delete t;
        t = NULL;
    }
}

// // public findMin
template <typename Comparable>
const Comparable & BST<Comparable>::findMin() const {
    if (root == NULL) 
	{
    	throw underflow_error("Tree is empty");
	}
    return findMin(root)->element;
}

// private findMin: refer to textbook, Figure 4.20
template <typename Comparable>
typename BST<Comparable>::BinaryNode* BST<Comparable>::findMin(BinaryNode * t) const 
{
	BinaryNode* n = this->root;
	while (n->left != nullptr)
	{
		n = n->left;
	}
	return n;

}

// public findMax
template <typename Comparable>
const Comparable & BST<Comparable>::findMax() const {
	
    if (root == NULL) {
    	throw underflow_error("Tree is empty");
	}
	
    return findMax(root)->element;
}

// private findMax: refer to textbook, Figure 4.21
template <typename Comparable>
typename BST<Comparable>::BinaryNode* BST<Comparable>::findMax(BinaryNode * t) const {
    BinaryNode* n = this->root;
	while (n->right != nullptr)
	{
		n = n->right;
	}
	return n;
}

// public contains: refer to textbook, Figure 4.17, Line 4 - 7
template<typename Comparable>
bool BST<Comparable>::contains( const Comparable & x ) const 
{
	static BinaryNode* n = this->root;

	
	
	if (n->element==x)
	{
		return true;
	}
	else
	{
		if (n->right != nullptr)
		{
			n = n->right;
			contains(x);
			if(contains(x))
			{return true }


			return false;
		}
		if (n->left != nullptr)
		{

			n = n->left;
			contains(x);
			if (contains(x))
			{
				return true
			}



			return false;
		}
	}
}

// public insert: refer to textbook, Figure 4.17, Line 12 - 15
template<typename Comparable>
void BST<Comparable>::insert(const Comparable & x) 
{
	BinaryNode* n = this->root;
	BinaryNode p = {};
	p.element = x;
	cout << "**TODO**: insert function" << endl;
	while (!contains(x))
	{
		if (n->element > x)
		{
			n = n->left;
		}
		if (n->element < x)
		{
			n = n->right;
		}
		if (n == nullptr)
		{
			n = p;
		}
	}
}


// public remove: refer to textbook, Figure 4.17, Line 20 - 23
template<typename Comparable>
void BST<Comparable>::remove( const Comparable & x ) {
	
	
		static BinaryNode* n = this->root;
		
		
	
	if (contains(x))
	{
		if (n->left != nullptr)
		{
			n = n->left;
			if (n->element == x)
			{
				n->element = -1;
			}
			remove(x);
		}
		if (n->right != nullptr)
		{
			n = n->right;
			if (n->element == x)
			{
				n->element = -1;
			}
			remove(x);
		}
	}
}

// public treeSize
template <typename Comparable>
int BST<Comparable>::treeSize() const {
	static int ts = 0;
	static BinaryNode* n = this->root;
	if (ts == 0)
	{
		
		ts++;
	}
	else {
		if (n->left != nullptr)
		{
			n = n->left;
			ts++;
			treesize();
		}
		if (n->right != nullptr)
		{
			n = n->right;
			ts++;
			treesize();
		}
	}
	return ts;
}

// public treeHeight
template <typename Comparable>
int BST<Comparable>::treeHeight() const {
	
	
	static int count = 1, tcount = 0;
	static BinaryNode* n = this->root;
	if (n->left != nullptr)
	{
		n = n->left;
		treeHeight();
		count++;
	}
	if (n->right != nullptr)
	{
		n = n->right;
		treeHeight();
		count++;
	}
	if (n->left == nullptr && n->right == nullptr)
	{
		if (count > tcount)
		{
			tcount = count;
		}
		count--;
	}
	return tcount;
}

// public printInOrder: refer to textbook, Figure 4.60
template<typename Comparable>
void BST<Comparable>::printInOrder() const {
	cout << "**TODO**: printInOrder function" << endl;
	static BinaryNode* n = this->root;

	if (n->left != nullptr)
	{
		n = n->left;
		printInOrder();
		cout << n->element;
	}
	if (n->right != nullptr)
	{
		n = n->right;
		printInOrder();
		cout << n->element;
	}

}

// public printLevels
template <typename Comparable>
void BST<Comparable>::printLevels() const {
	

}

// public printMaxPath
template <typename Comparable>
void BST<Comparable>::printMaxPath() const {
	cout << "**TODO**: printMaxPath function" << endl;
}

#endif
